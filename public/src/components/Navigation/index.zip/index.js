import React from "react";
import { Link } from "react-router-dom";

import SignOutButton from "../SignOut";

import * as ROUTES from "../../constants/routes";
import * as ROLES from "../../constants/roles";
import Navbar from "react-bootstrap/Navbar";
import Image from "react-bootstrap/Image";
import Nav from "react-bootstrap/Nav";

import { AuthUserContext } from "../../server/Session/index";
import "./style.css";
const route = value => {
  if (value) {
    return <Link to={ROUTES.CLIENT}>My Profile</Link>;
  } else {
    return <Link to={ROUTES.AGENTPROFILE}>My Profile</Link>;
  }
};

const Navigation = () => (
  <div>
    <AuthUserContext.Consumer>
      {authUser =>
        authUser ? (
          <NavigationAuth authUser={authUser} />
        ) : (
          <NavigationNonAuth />
        )
      }
    </AuthUserContext.Consumer>
  </div>
);

const NavigationAuth = ({ authUser }) => (
  <Nav className="justify-content-center NavigateX" activeKey="/Landing">
    <Nav.Item>
      <Link to={ROUTES.LANDING}>Landing</Link>
    </Nav.Item>
    <Nav.Item>
      <Link to={ROUTES.ACCOUNT}>Account</Link>
    </Nav.Item>
    {/* <Nav.Item>
      <Link to={ROUTES.HOME}>Home</Link>
    </Nav.Item> */}
    <Nav.Item>
      <Link to={ROUTES.HOUSE}>House</Link>
    </Nav.Item>

    <Nav.Item>{route(authUser.isClient === "true")}</Nav.Item>
    <Nav.Item>
      <SignOutButton />
    </Nav.Item>
  </Nav>

  // <ul>
  //   <li>
  //     <Link to={ROUTES.LANDING}>Landing</Link>
  //   </li>
  //   <li>
  //     <Link to={ROUTES.ACCOUNT}>Account</Link>
  //   </li>
  //   <li>
  //     <Link to={ROUTES.HOME}>Home</Link>
  //   </li>
  //   <li>
  //     <Link to={ROUTES.HOUSE}>House</Link>
  //   </li>
  //
  // {authUser.roles.includes(ROLES.CLIENT) && (
  //   <li>
  //     <Link to={ROUTES.CLIENT}>My Profile</Link>
  //   </li>
  // )}
  // {authUser.roles.includes(ROLES.AGENT) && (
  //   <li>
  //     <Link to={ROUTES.AGENT}>My Profile</Link>
  //   </li>
  // )}
  //   {authUser.roles.includes(ROLES.ADMIN) && (
  //     <li>
  //       <Link to={ROUTES.ADMIN}>ADMIN</Link>
  //     </li>
  //   )}
  //   <li>
  //     <SignOutButton />
  //   </li>
  // </ul>
);

const NavigationNonAuth = () => (
  <Navbar
    className="Navigation"
    collapseOnSelect
    expand="md"
    fixed="top"
    sticky="top"
  >
    <Navbar.Brand href={ROUTES.LANDING}>
      <Link to={ROUTES.LANDING}>
        <Image
          onClick={ROUTES.LANDING}
          swidth={100}
          height={100}
          src={"/images/logo2.png"}
          // window.location.origin +
        />
      </Link>
    </Navbar.Brand>

    <Navbar.Toggle aria-controls="responsive-navbar-nav" />

    <Navbar.Collapse className="leftSideNav">
      <Nav className="nav-item">
        <Nav.Item>
          <Nav.Link href={ROUTES.SIGN_IN}>
            <span className="textNav">{"Sign In"}</span>
          </Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link href={ROUTES.SIGN_UP}>
            <span className="textNav">{"Sign Up"}</span>
          </Nav.Link>
        </Nav.Item>
      </Nav>
    </Navbar.Collapse>
  </Navbar>
);

export default Navigation;
